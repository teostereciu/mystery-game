package nl.ai.rug.oop.rpg;

import nl.ai.rug.oop.rpg.view.GameView;

public class Main {
    public static void main(String[] args) {
        GameView view = new GameView();
    }
}
