package nl.ai.rug.oop.rpg.controller;

public class RoomChooser {
}
