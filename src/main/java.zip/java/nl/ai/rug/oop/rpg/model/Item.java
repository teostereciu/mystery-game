package nl.ai.rug.oop.rpg.model;

public class Item {
    //This class has a low priority, first work on the others

    public Item(){}
}
