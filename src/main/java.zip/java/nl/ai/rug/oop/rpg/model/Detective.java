package nl.ai.rug.oop.rpg.model;

public class Detective {

    public Detective(){

    }
}
